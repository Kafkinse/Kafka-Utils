package dev.kafka.kafkautils.util;

public final class Theme {
   public static final int ACCENT = -9826899;
   public static final int ACCENT_LIGHT = -6606593;
   public static final int ACCENT_DARK = -12976032;
   public static final int BORDEAUX = -8388560;
   public static final int PANEL_BG = -1072037850;
   public static final int PANEL_BORDER = -9826899;
   public static final int TEXT = -1517825;
   public static final int TEXT_DIM = -5009200;
   public static final int BLUE = -13388289;
   public static final int ORANGE = -29696;
   public static final String C_ACCENT = "§5";
   public static final String C_PINK = "§d";
   public static final String C_GREEN = "§a";
   public static final String C_RED = "§c";
   public static final String C_GRAY = "§7";
   public static final String C_BOLD = "§l";
   public static final String C_RESET = "§r";

   private Theme() {
   }
}
