package dev.kafka.kafkautils.util;

import net.minecraft.class_12179;
import net.minecraft.class_12180;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;

public final class Render3D {
   private Render3D() {
   }

   public static void drawBox(class_2338 pos, int argb) {
      class_12180.method_75550(pos, class_12179.method_75536(argb, 2.5F)).method_75533();
   }

   public static void drawFilledBox(class_2338 pos, int fillArgb, int strokeArgb) {
      class_12180.method_75550(pos, class_12179.method_75537(strokeArgb, 2.5F, fillArgb)).method_75533();
   }

   public static void drawBox(class_238 box, int argb) {
      class_12180.method_75541(box, class_12179.method_75536(argb, 2.5F)).method_75533();
   }

   public static void circle(class_243 center, float radius, int argb) {
      class_12180.method_75543(center, radius, class_12179.method_75536(argb, 2.5F)).method_75533();
   }

   public static void drawFilled(class_238 box, int argb) {
      class_12180.method_75541(box, class_12179.method_75539(argb)).method_75533();
   }

   public static void line(class_243 from, class_243 to, int argb) {
      class_12180.method_75546(from, to, argb, 2.0F).method_75533();
   }
}
