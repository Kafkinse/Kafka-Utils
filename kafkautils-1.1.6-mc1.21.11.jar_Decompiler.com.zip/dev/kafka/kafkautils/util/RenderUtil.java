package dev.kafka.kafkautils.util;

import java.util.List;
import java.util.Objects;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public final class RenderUtil {
   private RenderUtil() {
   }

   public static int[] panel(class_332 ctx, int x, int y, String title, List<String> lines) {
      class_327 font = class_310.method_1551().field_1772;
      Objects.requireNonNull(font);
      int lineHeight = 9 + 2;
      int width = font.method_1727(title) + 12;

      for(String line : lines) {
         width = Math.max(width, font.method_1727(line) + 12);
      }

      Objects.requireNonNull(font);
      int headerHeight = 9 + 6;
      int bodyHeight = lines.size() * lineHeight + 4;
      int totalHeight = headerHeight + bodyHeight;
      ctx.method_25294(x, y, x + width, y + totalHeight, -1072037850);
      ctx.method_25294(x, y, x + width, y + headerHeight, -12976032);
      ctx.method_25294(x, y, x + 2, y + totalHeight, -9826899);
      ctx.method_51433(font, "§d§l" + title, x + 5, y + 4, -1517825, false);
      int ty = y + headerHeight + 3;

      for(String line : lines) {
         ctx.method_51433(font, line, x + 6, ty, -1517825, true);
         ty += lineHeight;
      }

      return new int[]{width, totalHeight};
   }

   public static String roman(int n) {
      String var10000;
      switch (n) {
         case 1 -> var10000 = "I";
         case 2 -> var10000 = "II";
         case 3 -> var10000 = "III";
         case 4 -> var10000 = "IV";
         case 5 -> var10000 = "V";
         case 6 -> var10000 = "VI";
         case 7 -> var10000 = "VII";
         case 8 -> var10000 = "VIII";
         case 9 -> var10000 = "IX";
         case 10 -> var10000 = "X";
         default -> var10000 = Integer.toString(n);
      }

      return var10000;
   }

   public static String time(int seconds) {
      if (seconds < 0) {
         return "∞";
      } else {
         int m = seconds / 60;
         int s = seconds % 60;
         return String.format("%d:%02d", m, s);
      }
   }
}
