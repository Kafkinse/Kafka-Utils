package dev.kafka.kafkautils.util;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_640;
import net.minecraft.class_742;

public final class StaffCounter {
   public static final char HELPER = 'Ⓗ';
   public static final char MOD = 'Ⓜ';
   public static final char ADMIN = 'Ⓐ';

   private StaffCounter() {
   }

   public static int[] counts() {
      class_310 mc = class_310.method_1551();
      int h = 0;
      int m = 0;
      int a = 0;
      if (mc.method_1562() != null) {
         for(class_640 e : mc.method_1562().method_2880()) {
            String s = display(e);
            if (s.indexOf(9405) >= 0) {
               ++h;
            }

            if (s.indexOf(9410) >= 0) {
               ++m;
            }

            if (s.indexOf(9398) >= 0) {
               ++a;
            }
         }
      }

      return new int[]{h, m, a};
   }

   public static List<String> staffNames() {
      class_310 mc = class_310.method_1551();
      List<String> admins = new ArrayList();
      List<String> mods = new ArrayList();
      List<String> helpers = new ArrayList();
      if (mc.method_1562() != null) {
         for(class_640 e : mc.method_1562().method_2880()) {
            String s = display(e);
            String name = e.method_2966() != null ? e.method_2966().name() : s;
            if (s.indexOf(9398) >= 0) {
               admins.add("Ⓐ " + name);
            } else if (s.indexOf(9410) >= 0) {
               mods.add("Ⓜ " + name);
            } else if (s.indexOf(9405) >= 0) {
               helpers.add("Ⓗ " + name);
            }
         }
      }

      List<String> out = new ArrayList();
      out.addAll(admins);
      out.addAll(mods);
      out.addAll(helpers);
      return out;
   }

   public static List<String> hiddenPlayers() {
      class_310 mc = class_310.method_1551();
      List<String> out = new ArrayList();
      if (mc.field_1687 != null && mc.field_1724 != null) {
         for(class_742 p : mc.field_1687.method_18456()) {
            if (p != mc.field_1724 && !p.method_5667().equals(mc.field_1724.method_5667()) && p.method_5767()) {
               out.add(p.method_5477().getString());
            }
         }

         return out;
      } else {
         return out;
      }
   }

   private static String display(class_640 e) {
      class_2561 d = e.method_2971();
      if (d != null) {
         return d.getString();
      } else {
         return e.method_2966() != null ? e.method_2966().name() : "";
      }
   }
}
