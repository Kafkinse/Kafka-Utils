package dev.kafka.kafkautils.module;

import dev.kafka.kafkautils.module.modules.chat.AntiSpam;
import dev.kafka.kafkautils.module.modules.chat.ChatPing;
import dev.kafka.kafkautils.module.modules.chat.PlayerLogger;
import dev.kafka.kafkautils.module.modules.chat.PlayerTracker;
import dev.kafka.kafkautils.module.modules.chat.StaffList;
import dev.kafka.kafkautils.module.modules.chat.StaffNotify;
import dev.kafka.kafkautils.module.modules.combat.AutoBadOmen;
import dev.kafka.kafkautils.module.modules.combat.AutoRaid;
import dev.kafka.kafkautils.module.modules.combat.DamageLog;
import dev.kafka.kafkautils.module.modules.combat.EnemyStatus;
import dev.kafka.kafkautils.module.modules.combat.GappleCount;
import dev.kafka.kafkautils.module.modules.combat.PvPLogger;
import dev.kafka.kafkautils.module.modules.combat.SplashPredictor;
import dev.kafka.kafkautils.module.modules.combat.TotemCounter;
import dev.kafka.kafkautils.module.modules.render.ActiveModsHud;
import dev.kafka.kafkautils.module.modules.render.DiamondOreEsp;
import dev.kafka.kafkautils.module.modules.render.EffectLogger;
import dev.kafka.kafkautils.module.modules.render.HealthESP;
import dev.kafka.kafkautils.module.modules.render.ItemESP;
import dev.kafka.kafkautils.module.modules.render.OminousVaultHighlighter;
import dev.kafka.kafkautils.module.modules.render.PlayerInspect;
import dev.kafka.kafkautils.module.modules.render.Tracers;
import dev.kafka.kafkautils.module.modules.render.TrialSpawnerEsp;
import dev.kafka.kafkautils.module.modules.render.VanishESP;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
   private static final List<Module> MODULES = new ArrayList();

   private ModuleManager() {
   }

   public static void init() {
      register(new AutoRaid());
      register(new AutoBadOmen());
      register(new TotemCounter());
      register(new EnemyStatus());
      register(new PvPLogger());
      register(new GappleCount());
      register(new SplashPredictor());
      register(new DamageLog());
      register(new EffectLogger());
      register(new TrialSpawnerEsp());
      register(new OminousVaultHighlighter());
      register(new DiamondOreEsp());
      register(new PlayerInspect());
      register(new VanishESP());
      register(new HealthESP());
      register(new Tracers());
      register(new ItemESP());
      register(new ActiveModsHud());
      register(new PlayerLogger());
      register(new StaffNotify());
      register(new PlayerTracker());
      register(new StaffList());
      register(new ChatPing());
      register(new AntiSpam());
   }

   private static void register(Module module) {
      MODULES.add(module);
   }

   public static List<Module> getModules() {
      return MODULES;
   }

   public static List<Module> getByCategory(Category category) {
      List<Module> result = new ArrayList();

      for(Module m : MODULES) {
         if (m.getCategory() == category) {
            result.add(m);
         }
      }

      return result;
   }

   public static void onTick() {
      for(Module m : MODULES) {
         if (m.isEnabled()) {
            try {
               m.onTick();
            } catch (Throwable t) {
               m.setEnabled(false);
               PrintStream var10000 = System.err;
               String var10001 = m.getName();
               var10000.println("[KafkaUtils] Disabled '" + var10001 + "' after a tick error: " + String.valueOf(t));
            }
         }
      }

   }

   public static <T extends Module> T get(Class<T> type) {
      for(Module m : MODULES) {
         if (type.isInstance(m)) {
            return (T)m;
         }
      }

      return null;
   }
}
