package dev.kafka.kafkautils.module.modules.render;

import dev.kafka.kafkautils.module.Category;
import dev.kafka.kafkautils.module.HudModule;
import dev.kafka.kafkautils.module.Module;
import dev.kafka.kafkautils.module.WorldRenderModule;
import dev.kafka.kafkautils.setting.BooleanSetting;
import dev.kafka.kafkautils.util.Render3D;
import dev.kafka.kafkautils.util.RenderUtil;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_332;

public class DiamondOreEsp extends Module implements WorldRenderModule, HudModule {
   private static final int SCAN_INTERVAL = 20;
   private static final int MAX_RADIUS = 8;
   private static final int FILL_DIAMOND = 1610671615;
   private static final int STROKE_DIAMOND = -16718337;
   private static final int FILL_DEEPSLATE = 1612232920;
   private static final int STROKE_DEEPSLATE = -15157032;
   private final BooleanSetting showDiamond = (BooleanSetting)this.add(new BooleanSetting("Diamond", true));
   private final BooleanSetting showDeepslate = (BooleanSetting)this.add(new BooleanSetting("Deepslate Diamond", true));
   private final List<class_2338> diamond = new ArrayList();
   private final List<class_2338> deepslate = new ArrayList();
   private int scanTimer = 0;

   public DiamondOreEsp() {
      super("Diamond ESP", "Подсветка алмазной руды сквозь блоки.", Category.RENDER);
   }

   protected void onEnable() {
      this.scanTimer = 0;
      this.diamond.clear();
      this.deepslate.clear();
   }

   protected void onDisable() {
      this.diamond.clear();
      this.deepslate.clear();
   }

   public void onTick() {
      if (mc.field_1687 != null && mc.field_1724 != null) {
         if (this.scanTimer-- <= 0) {
            this.scanTimer = 20;
            this.rescan();
         }
      }
   }

   private boolean isTrackedOre(class_2680 state) {
      if (this.showDiamond.get() && state.method_27852(class_2246.field_10442)) {
         return true;
      } else {
         return this.showDeepslate.get() && state.method_27852(class_2246.field_29029);
      }
   }

   private void rescan() {
      this.diamond.clear();
      this.deepslate.clear();
      if (this.showDiamond.get() || this.showDeepslate.get()) {
         int radius = Math.min(8, (Integer)mc.field_1690.method_42503().method_41753());
         class_1923 center = mc.field_1724.method_31476();

         for(int cx = center.field_9181 - radius; cx <= center.field_9181 + radius; ++cx) {
            for(int cz = center.field_9180 - radius; cz <= center.field_9180 + radius; ++cz) {
               class_2791 chunk = mc.field_1687.method_8497(cx, cz);
               if (chunk instanceof class_2818) {
                  class_2818 worldChunk = (class_2818)chunk;
                  this.scanChunk(worldChunk, cx << 4, cz << 4);
               }
            }
         }

      }
   }

   private void scanChunk(class_2818 chunk, int originX, int originZ) {
      class_2826[] sections = chunk.method_12006();

      for(int i = 0; i < sections.length; ++i) {
         class_2826 section = sections[i];
         if (section != null && !section.method_38292() && section.method_19523(this::isTrackedOre)) {
            int baseY = mc.field_1687.method_31604(i) << 4;

            for(int x = 0; x < 16; ++x) {
               for(int y = 0; y < 16; ++y) {
                  for(int z = 0; z < 16; ++z) {
                     class_2680 state = section.method_12254(x, y, z);
                     if (this.showDiamond.get() && state.method_27852(class_2246.field_10442)) {
                        this.diamond.add(new class_2338(originX + x, baseY + y, originZ + z));
                     } else if (this.showDeepslate.get() && state.method_27852(class_2246.field_29029)) {
                        this.deepslate.add(new class_2338(originX + x, baseY + y, originZ + z));
                     }
                  }
               }
            }
         }
      }

   }

   public void onWorldRender(WorldRenderContext ctx) {
      for(class_2338 pos : this.diamond) {
         Render3D.drawFilledBox(pos, 1610671615, -16718337);
      }

      for(class_2338 pos : this.deepslate) {
         Render3D.drawFilledBox(pos, 1612232920, -15157032);
      }

   }

   public int[] onHudRender(class_332 ctx, int x, int y) {
      List<String> lines = new ArrayList();
      lines.add("§dАлмазной: §r" + this.diamond.size());
      lines.add("§7Глубинной: §r" + this.deepslate.size());
      return RenderUtil.panel(ctx, x, y, "Diamond ESP", lines);
   }
}
