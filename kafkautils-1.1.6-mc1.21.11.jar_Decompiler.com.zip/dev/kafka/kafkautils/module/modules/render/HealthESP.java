package dev.kafka.kafkautils.module.modules.render;

import dev.kafka.kafkautils.module.Category;
import dev.kafka.kafkautils.module.Module;
import dev.kafka.kafkautils.module.WorldRenderModule;
import dev.kafka.kafkautils.util.Render3D;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_742;

public class HealthESP extends Module implements WorldRenderModule {
   public HealthESP() {
      super("Health ESP", "HP bar above players in the world.", Category.RENDER);
   }

   public void onWorldRender(WorldRenderContext ctx) {
      if (mc.field_1687 != null && mc.field_1724 != null) {
         for(class_742 p : mc.field_1687.method_18456()) {
            if (p != mc.field_1724) {
               float max = p.method_6063();
               if (!(max <= 0.0F)) {
                  float frac = Math.max(0.0F, Math.min(1.0F, p.method_6032() / max));
                  class_243 pos = p.method_73189();
                  double topY = pos.field_1351 + (double)p.method_17682() + 0.4;
                  double w = (double)1.0F;
                  class_238 bg = new class_238(pos.field_1352 - w / (double)2.0F, topY, pos.field_1350 - 0.04, pos.field_1352 + w / (double)2.0F, topY + 0.12, pos.field_1350 + 0.04);
                  class_238 fg = new class_238(pos.field_1352 - w / (double)2.0F, topY, pos.field_1350 - 0.04, pos.field_1352 - w / (double)2.0F + w * (double)frac, topY + 0.12, pos.field_1350 + 0.04);
                  Render3D.drawFilled(bg, -1608507356);
                  Render3D.drawFilled(fg, hpColor(frac));
               }
            }
         }

      }
   }

   private static int hpColor(float f) {
      int r = (int)(255.0F * (1.0F - f));
      int g = (int)(255.0F * f);
      return -16777216 | r << 16 | g << 8;
   }
}
