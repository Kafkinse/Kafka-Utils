package dev.kafka.kafkautils.module.modules.render;

import dev.kafka.kafkautils.module.Category;
import dev.kafka.kafkautils.module.Module;
import dev.kafka.kafkautils.module.WorldRenderModule;
import dev.kafka.kafkautils.util.Render3D;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_243;
import net.minecraft.class_742;

public class Tracers extends Module implements WorldRenderModule {
   public Tracers() {
      super("Tracers", "Lines to players.", Category.RENDER);
   }

   public void onWorldRender(WorldRenderContext ctx) {
      if (mc.field_1687 != null && mc.field_1724 != null) {
         class_243 eye = mc.field_1724.method_33571();

         for(class_742 p : mc.field_1687.method_18456()) {
            if (p != mc.field_1724) {
               class_243 to = p.method_73189().method_1031((double)0.0F, (double)p.method_17682() * (double)0.5F, (double)0.0F);
               Render3D.line(eye, to, -6606593);
            }
         }

      }
   }
}
